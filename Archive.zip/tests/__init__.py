"""
Test package for the cost estimator service.
"""
