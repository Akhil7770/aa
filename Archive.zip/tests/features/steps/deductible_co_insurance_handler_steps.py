from behave import given, when, then  # type: ignore
from app.services.handlers.deductible_co_insurance_handler import (
    DeductibleCoInsuranceHandler,
)
from app.core.base import InsuranceContext


@given("an DeductibleCoInsuranceHandler is created")
def step_create_deductible_co_insurance_handler(context):
    """Create a DeductibleCoInsuranceHandler with insurance context"""
    context.handler = DeductibleCoInsuranceHandler()
    context.insurance_context = InsuranceContext()
    # Initialize member_pays to 0 for clean test state
    context.insurance_context.member_pays = 0.0
    context.insurance_context.amount_coinsurance = 0.0


@given("the co-insurance percent is {amount}")
def step_co_insurance_percent(context, amount):
    """Set the co-insurance percentage in the insurance context"""
    context.insurance_context.cost_share_coinsurance = float(amount)


@given("co-insurance applies to OOPMax {value}")
def step_co_insurance_applies_to_oopmax(context, value):
    """Set whether co-insurance applies to OOPMax"""
    context.insurance_context.coins_applies_oop = value.lower() == "true"


@given("the benefit code is {code}")
def step_benefit_code(context, code):
    """Set the benefit code in the insurance context"""
    context.insurance_context.accum_code = code


@given("the benefit level is {level}")
def step_benefit_level(context, level):
    """Set the benefit level in the insurance context"""
    context.insurance_context.accum_level = level


@given("the member has already paid {amount}")
def step_member_already_paid(context, amount):
    """Set the amount the member has already paid"""
    context.insurance_context.member_pays = float(amount)


@given("the member pays is {amount}")
def step_member_pays_is(context, amount):
    """Set the member pays amount directly"""
    context.insurance_context.member_pays = float(amount)


@given("the co-insurance amount is {amount}")
def step_coinsurance_amount_is(context, amount):
    """Set the co-insurance amount directly"""
    context.insurance_context.amount_coinsurance = float(amount)


@given("the amount copay is {amount}")
def step_amount_copay(context, amount):
    """Set the amount copay in the insurance context"""
    context.insurance_context.amount_copay = float(amount)


@given("the service is covered {value}")
def step_service_covered(context, value):
    """Set whether the service is covered"""
    context.insurance_context.is_service_covered = value.lower() == "true"


@given("the message is {message}")
def step_message(context, message):
    """Set the message in the insurance context"""
    context.insurance_context.message = message


@given("the trace decision is {decision}")
def step_trace_decision(context, decision):
    """Set the trace decision in the insurance context"""
    context.insurance_context.trace_decision = decision


@given("the trace is {trace}")
def step_trace(context, trace):
    """Set the trace in the insurance context"""
    context.insurance_context.trace = trace


@given("the trace decision result is {result}")
def step_trace_decision_result(context, result):
    """Set the trace decision result in the insurance context"""
    context.insurance_context.trace_decision_result = result


@given("the trace decision message is {message}")
def step_trace_decision_message(context, message):
    """Set the trace decision message in the insurance context"""
    context.insurance_context.trace_decision_message = message


@given("the trace decision code is {code}")
def step_trace_decision_code(context, code):
    """Set the trace decision code in the insurance context"""
    context.insurance_context.trace_decision_code = code


@given("the trace decision level is {level}")
def step_trace_decision_level(context, level):
    """Set the trace decision level in the insurance context"""
    context.insurance_context.trace_decision_level = level


@then("the co-insurance amount is {amount}")
def step_coinsurance_amount(context, amount):
    """Verify the co-insurance amount is correct"""
    expected_amount = float(amount)
    actual_amount = context.result.amount_coinsurance
    assert actual_amount == expected_amount, f"Expected co-insurance amount to be {expected_amount}, but it is {actual_amount}"


@then("the remaining service cost is {amount}")
def step_remaining_service_cost(context, amount):
    """Verify the remaining service cost is correct"""
    expected_amount = float(amount)
    actual_amount = context.result.service_amount
    assert actual_amount == expected_amount, f"Expected remaining service cost to be {expected_amount}, but it is {actual_amount}"
