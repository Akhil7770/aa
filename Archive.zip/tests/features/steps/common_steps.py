from behave import given, when, then  # type: ignore


@given("the service cost is {amount}")
def step_service_cost(context, amount):
    # Store the original service amount for insurance pays calculation
    context.insurance_context.original_service_amount = float(amount)
    context.insurance_context.service_amount = float(amount)


@given("the individual deductible is {amount}")
def step_individual_deductible(context, amount):
    context.insurance_context.deductible_individual_calculated = float(amount)


@given("the family deductible is {amount}")
def step_family_deductible(context, amount):
    context.insurance_context.deductible_family_calculated = float(amount)


@given("the deductible is before co-pay {value}")
def step_deductible_before_copay(context, value):
    context.insurance_context.is_deductible_before_copay = value.lower() == "true"


@given("a cost share co-pay is {amount}")
def step_cost_share_copay(context, amount):
    context.insurance_context.cost_share_copay = float(amount)


@when("the handler processes the context")
def step_handler_processes(context):
    # Debug output before processing
    print(f"\nDEBUG - Before Handler Processing:")
    print(f"  Service amount: {context.insurance_context.service_amount}")
    print(f"  Member co-pay: {context.insurance_context.cost_share_copay}")
    print(f"  Individual OOPMax: {context.insurance_context.oopmax_individual_calculated}")
    print(f"  Family OOPMax: {context.insurance_context.oopmax_family_calculated}")
    print(f"  Copay continue indicator: {getattr(context.insurance_context, 'copaycontinuewhenoutpocketmaxmetindicator', 'Not set')}")
    
    # Process the context
    context.result = context.handler.process(context.insurance_context)
    
    # Debug output after processing
    print(f"\nDEBUG - After Handler Processing:")
    if context.result is not None:
        print(f"  Service amount: {context.result.service_amount}")
        print(f"  Member pays: {context.result.member_pays}")
        print(f"  Individual OOPMax: {context.result.oopmax_individual_calculated}")
        print(f"  Family OOPMax: {context.result.oopmax_family_calculated}")
        print(f"  Cost share copay: {context.result.cost_share_copay}")
        print(f"  Amount copay: {context.result.amount_copay}")
        print(f"  Calculation complete: {context.result.calculation_complete}")
    else:
        print(f"  Handler returned None - no result object")
        print(f"  This indicates the handler did not call the expected next handler")


@then("the result should indicate the service is covered")
def step_service_covered(context):
    assert context.result.is_service_covered is True
    # Note: InsuranceContext doesn't have a 'message' attribute
    # The handler sets error_message when service is not covered


@then("the result should indicate the service is not covered")
def step_service_not_covered(context):
    assert context.result.is_service_covered is False
    assert context.result.error_message == "The service is not covered"
    assert context.result.member_pays == context.insurance_context.service_amount
    assert context.result.calculation_complete is True


@then("the calculation is not complete")
def step_calculation_not_complete(context):
    assert context.result.calculation_complete is False


@then("the calculation is complete")
def step_calculation_complete(context):
    assert context.result.calculation_complete is True


# @then("the insurance pays {amount}")
# def step_insurance_pays(context, amount):
#     assert context.result.insurance_pays == float(amount)


@then("the member pays {amount}")
def step_member_pays(context, amount):
    assert context.result.member_pays == float(amount)


@then("the individual OOPMax is updated to {amount}")
def step_individual_oopmax_updated(context, amount):
    assert context.result.oopmax_individual_calculated == float(amount)


@then("the family OOPMax is updated to {amount}")
def step_family_oopmax_updated(context, amount):
    assert context.result.oopmax_family_calculated == float(amount)


@given("the member co-pay is {amount:d}")
def step_member_copay(context, amount):
    context.insurance_context.cost_share_copay = float(amount)


@then("the individual deductible is updated to {amount:d}")
def step_individual_deductible_updated(context, amount):
    expected_amount = float(amount)
    actual_amount = context.result.deductible_individual_calculated
    assert actual_amount == expected_amount, f"Expected individual deductible to be {expected_amount}, but it is {actual_amount}"


@then("the family deductible is updated to {amount:d}")
def step_family_deductible_updated(context, amount):
    expected_amount = float(amount)
    actual_amount = context.result.deductible_family_calculated
    assert actual_amount == expected_amount, f"Expected family deductible to be {expected_amount}, but it is {actual_amount}"


@then("the service amount is updated to {amount:d}")
def step_service_amount_updated(context, amount):
    context.insurance_context.service_amount = float(amount)


@then("the co-insurance is checked")
def step_coinsurance_checked(context):
    # Try different possible mock handler names that might be used in different contexts
    if hasattr(context, 'mock_co_insurance_handler'):
        context.mock_co_insurance_handler.handle.assert_called_once_with(context.insurance_context)
    elif hasattr(context, 'mock_deductible_co_insurance_handler'):
        context.mock_deductible_co_insurance_handler.handle.assert_called_once_with(context.insurance_context)
    else:
        raise AttributeError("No mock co-insurance handler found in context")


@then("the co-pay is checked")
def step_copay_checked(context):
    context.mock_cost_share_co_pay_handler.assert_called_once_with(
        context.insurance_context
    )
