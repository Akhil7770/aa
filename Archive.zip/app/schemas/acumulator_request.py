import json
import re
import uuid
from datetime import datetime
from typing import Dict, Optional

from app.schemas.cost_estimator_request import CostEstimatorRequest


class AccumulatorRequestBuilder:
    """Builder class for creating XML accumulator requests."""

    def _convert_to_dict(self, value) -> dict:
        """
        Convert header value to dictionary.

        Args:
            value: Header value (string or dict)

        Returns:
            Dictionary representation
        """

        if value is None:
            print("Input is None, returning empty dict")
            return {}
        elif isinstance(value, dict):
            print(f"Input is dict, returning as-is: {value}")
            return value
        elif isinstance(value, str):
            try:
                result = json.loads(value)
                return result
            except (json.JSONDecodeError, TypeError):
                raise ValueError(f"Invalid JSON: {value}")
        else:
            raise ValueError(f"Unknown type {type(value)}")

    def build_xml_request(
        self, request: CostEstimatorRequest, headers: Optional[Dict[str, str]] = None
    ) -> str:
        """
        Build XML request for accumulator service.

        Args:
            request: The cost estimator request
            headers: Optional headers for the request

        Returns:
            str: The complete XML request
        """
        current_date = datetime.now().strftime("%Y-%m-%d")
        transaction_id = uuid.uuid4()
        membership_id = request.membershipId
        benefit_product_type = request.benefitProductType

        if headers:
            for key, value in headers.items():
                if not value or value == "":
                    raise ValueError(f"Header {key} is required")

        eieHeaderAuthorizedRole = ""
        user_context = headers.get("EIE-Header-User-Context", {}) if headers else {}
        if isinstance(user_context, str):
            try:
                user_context = json.loads(user_context)
            except (json.JSONDecodeError, TypeError):
                user_context = {}
        roles = user_context.get("eieHeaderUserContext", {}).get(
            "eieHeaderAuthorizedRole", []
        )
        for dict_value in roles:
            eieHeaderAuthorizedRole += f'<p2:eieHeaderAuthorizedRole><p3:authorizedRole>{dict_value.get("authorizedRole","")}</p3:authorizedRole></p2:eieHeaderAuthorizedRole>'

        xml_request = f"""<?xml version="1.0" encoding="UTF-8"?>
<qns:accumulatorsRequest xmlns:qns="http://schema.aetna.com/member/accumulators/v4" xmlns:p="http://www.aetna.com/cmm/interface/EIEHeader/v14" xmlns:p1="http://www.aetna.com/cmm/common/Identifier/v14" xmlns:p2="http://www.aetna.com/cmm/interface/EIEHeaderUserContext/v14" xmlns:p3="http://www.aetna.com/cmm/interface/EIEHeaderAuthorizedRole/v14" xmlns:p4="http://www.aetna.com/cmm/interface/EIEHeaderVersion/v14" xmlns:p5="http://www.aetna.com/cmm/interface/Status/v14" xmlns:p6="http://www.aetna.com/cmm/interface/AdditionalStatus/v14" xmlns:schemaLocation="http://schema.aetna.com/member/accumulators/v3 Accumulators_v3.xsd " xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <qns:eieHeader>
        <p:action>{headers.get("EIE-Header-Action","") if headers else ""}</p:action>
    <p:accessToken/>
    <p:transactionID>{transaction_id}</p:transactionID>
    <p:multiPath>2</p:multiPath>
    <p:applicationIdentifier>
      <p1:idSource>{self._convert_to_dict(headers.get("EIE-Header-Application-Identifier", {})).get("applicationIdentifier", {}).get("idSource","") if headers and headers.get("EIE-Header-Application-Identifier") else ""}</p1:idSource>
      <p1:idValue>{self._convert_to_dict(headers.get("EIE-Header-Application-Identifier", {})).get("applicationIdentifier", {}).get("idValue","") if headers and headers.get("EIE-Header-Application-Identifier") else ""}</p1:idValue>
      <p1:idType>{self._convert_to_dict(headers.get("EIE-Header-Application-Identifier", {})).get("applicationIdentifier", {}).get("idType","") if headers and headers.get("EIE-Header-Application-Identifier") else ""}</p1:idType>
    </p:applicationIdentifier>
    <p:eieHeaderUserContext>
      <p2:assuranceLevel>{self._convert_to_dict(headers.get("EIE-Header-User-Context", {})).get("eieHeaderUserContext",{}).get("assuranceLevel","") if headers and headers.get("EIE-Header-User-Context") else ""}</p2:assuranceLevel>
      <p2:dnAccountName>{self._convert_to_dict(headers.get("EIE-Header-User-Context", {})).get("eieHeaderUserContext",{}).get("dnAccountName","") if headers and headers.get("EIE-Header-User-Context") else ""}</p2:dnAccountName>
      {eieHeaderAuthorizedRole}
      <p2:accountIdentifier>
        <p1:idSource>{self._convert_to_dict(headers.get("EIE-Header-User-Context", {})).get("eieHeaderUserContext",{}).get("accountIdentifier",{}).get("idSource","") if headers and headers.get("EIE-Header-User-Context") else ""}</p1:idSource>
        <p1:idValue>{self._convert_to_dict(headers.get("EIE-Header-User-Context", {})).get("eieHeaderUserContext",{}).get("idValue","") if headers and headers.get("EIE-Header-User-Context") else ""}</p1:idValue>
        <p1:idType>{self._convert_to_dict(headers.get("EIE-Header-User-Context", {})).get("eieHeaderUserContext",{}).get("accountIdentifier",{}).get("idType","") if headers and headers.get("EIE-Header-User-Context") else ""}</p1:idType>
      </p2:accountIdentifier>
    </p:eieHeaderUserContext>
    <p:eieHeaderVersion>
      <p4:major>{self._convert_to_dict(headers.get("EIE-Header-Version", {})).get("eieHeaderVersion", {}).get("major","") if headers and headers.get("EIE-Header-Version") else ""}</p4:major>
      <p4:minor>{self._convert_to_dict(headers.get("EIE-Header-Version", {})).get("eieHeaderVersion", {}).get("minor","") if headers and headers.get("EIE-Header-Version") else ""}</p4:minor>
      <p4:maintenance>{self._convert_to_dict(headers.get("EIE-Header-Version", {})).get("eieHeaderVersion", {}).get("maintenance","") if headers and headers.get("EIE-Header-Version") else ""}</p4:maintenance>
    </p:eieHeaderVersion>
  </qns:eieHeader>
  <qns:readAccumulatorsRequest>
    <qns:membershipIdentifier>
      <qns:idSource>{re.split(r'[~]', membership_id)[0]}</qns:idSource>
      <qns:idValue>{re.split(r'[~]', membership_id)[1]}</qns:idValue>
      <qns:idType>memberships</qns:idType>
      <qns:resourceId>{membership_id}</qns:resourceId>
    </qns:membershipIdentifier>
    <qns:benefitsPlanType>{benefit_product_type}</qns:benefitsPlanType>
    <qns:datetimeAsOf>{current_date}</qns:datetimeAsOf>
    <qns:familyAccumFilter>N</qns:familyAccumFilter>
  </qns:readAccumulatorsRequest>
</qns:accumulatorsRequest>"""

        return xml_request

    def remove_namespaces(self, obj):
        """
        Remove namespace prefixes from XML keys and filter out unwanted elements.

        Args:
            obj: The parsed XML object (dict, list, or primitive)

        Returns:
            The cleaned object with namespace prefixes removed
        """
        if isinstance(obj, dict):
            new_obj = {}
            for key, value in obj.items():
                clean_key = key.split(":", 1)[-1] if ":" in key else key
                processed_value = self.remove_namespaces(value)

                # Ensure dependents is always a list
                if clean_key == "dependents" and not isinstance(processed_value, list):
                    processed_value = (
                        [processed_value] if processed_value is not None else []
                    )

                new_obj[clean_key] = processed_value
            return new_obj
        elif isinstance(obj, list):
            return [self.remove_namespaces(item) for item in obj]
        else:
            return obj
