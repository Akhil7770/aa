SELECT MAX(RATE) AS RATE
FROM CET_CLAIM_BASED_AMOUNTS
WHERE
    PROVIDER_IDENTIFICATION_NBR = @provideridentificationnumber
    AND NETWORK_ID = @networkid
    AND PLACE_OF_SERVICE_CD = @placeofservice
    AND SERVICE_CD = @servicecd
    AND SERVICE_TYPE_CD = @servicetype