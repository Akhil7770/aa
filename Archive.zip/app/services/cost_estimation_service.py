from abc import ABC, abstractmethod


class CostEstimationServiceInterface(ABC):
    @abstractmethod
    async def estimate_cost(self, request):
        pass
