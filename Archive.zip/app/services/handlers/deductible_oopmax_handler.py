from app.core.base import Handler, InsuranceContext


class DeductibleOOPMaxHandler(Handler):
    """Handles logic for OOPMax calculations for deductibles"""

    def set_deductible_co_insurance_handler(self, handler):
        self._deductible_co_insurance_handler = handler
        return handler

    def set_deductible_cost_share_co_pay_handler(self, handler):
        self._deductible_cost_share_co_pay_handler = handler
        return handler

    def process(self, context):

        if context.calculation_complete:
            context.trace(
                "Process", "Calculation should not be marked as complete yet!!"
            )

        if context.deductible_applies_oop:
            context.trace_decision("Process", "The deductible applies to OOP", True)
            context = self._apply_member_pays_service_or_individual_deductible_is_applied_to_oopmax(
                context
            )
        else:
            context.trace_decision(
                "Process", "The deductible does not apply to OOP", False
            )
            context = self._apply_member_pays_service_or_individual_deductible_not_applied_to_oopmax(
                context
            )

        if context.calculation_complete:
            return context

        if context.is_deductible_before_copay:
            context.trace_decision("Process", "The deductible is before co-pay", True)
            return self._deductible_cost_share_co_pay_handler.handle(context)
        else:
            context.trace_decision(
                "Process",
                "The deductible is after co-pay, so checking for coinsurance",
                False,
            )
            return self._deductible_co_insurance_handler.handle(context)

    def _apply_member_pays_service_or_individual_deductible_not_applied_to_oopmax(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays lesser of the service or Individual Deductible and it will not count towards OOPMax"""

        if (
            context.deductible_individual_calculated is not None
            and context.service_amount < context.deductible_individual_calculated
        ):
            context.member_pays += context.service_amount
            if context.deductible_family_calculated is not None:
                context.deductible_family_calculated -= context.service_amount
            context.deductible_individual_calculated -= context.service_amount
            context.service_amount = 0

            context.calculation_complete = True
        elif context.deductible_individual_calculated is not None:
            context.member_pays += context.deductible_individual_calculated
            if context.deductible_family_calculated is not None:
                context.deductible_family_calculated -= (
                    context.deductible_individual_calculated
                )
            context.service_amount -= context.deductible_individual_calculated
            context.deductible_individual_calculated = 0

            # another step, then must go to deductible_co_insurance_handler

        context.trace(
            "_apply_member_pays_service_or_individual_deductible_not_applied_to_oopmax",
            "Logic applied",
        )

        return context

    def _apply_member_pays_service_or_individual_deductible_is_applied_to_oopmax(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays lesser of the service or individual deductible and it will get counted towards individual and family OOPMax"""

        if (
            context.deductible_individual_calculated is not None
            and context.service_amount < context.deductible_individual_calculated
        ):
            context.member_pays += context.service_amount
            if context.oopmax_family_calculated is not None:
                context.oopmax_family_calculated -= context.service_amount
            if context.oopmax_individual_calculated is not None:
                context.oopmax_individual_calculated -= context.service_amount
            if context.deductible_family_calculated is not None:
                context.deductible_family_calculated -= context.service_amount
            if context.deductible_individual_calculated is not None:
                context.deductible_individual_calculated -= context.service_amount
            context.service_amount = 0

            context.calculation_complete = True
        elif context.deductible_individual_calculated is not None:
            context.member_pays += context.deductible_individual_calculated
            if context.deductible_family_calculated is not None:
                context.deductible_family_calculated -= (
                    context.deductible_individual_calculated
                )
            if context.oopmax_family_calculated is not None:
                context.oopmax_family_calculated -= (
                    context.deductible_individual_calculated
                )
            if context.oopmax_individual_calculated is not None:
                context.oopmax_individual_calculated -= (
                    context.deductible_individual_calculated
                )
            context.service_amount -= context.deductible_individual_calculated
            context.deductible_individual_calculated = 0

            # another step, then must go to deductible_co_insurance_handler

        context.trace(
            "_apply_member_pays_service_or_individual_deductible_is_applied_to_oopmax",
            "Logic applied",
        )

        return context
