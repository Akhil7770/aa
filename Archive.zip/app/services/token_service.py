import json
import ssl
import os
from typing import Dict, Any

import aiohttp
from tenacity import retry, stop_after_attempt, wait_exponential

# from app.core.constants import TOKEN_URL, TOKEN_AUTHORIZATION, ASSERTION
from app.core.logger import logger
from app.core.constants import TOKEN_AUTHORIZATION, ASSERTION
from app.core.circuitbreaker.circuit_breaker import circuit_breaker


class TokenService:
    """Service for handling authentication token operations."""

    def __init__(self):
        # Create SSL context that doesn't verify certificates
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE

    async def get_new_token_will_implement_later(self) -> Dict[str, Any]:
        """
        Get a new authentication token.

        Returns:
            Dict[str, Any]: Token data containing access_token and id_token

        Raises:
            Exception: If token retrieval fails
        """
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }

        TOKEN_URL = os.getenv("TOKEN_URL")
        if not TOKEN_URL:
            raise ValueError("TOKEN_URL environment variable is not set")
        # For form-urlencoded, use data instead of json
        payload = {
            "scope": "APPPII APPPHI",
            "grant_type": "client_credentials",
            "client_id": os.getenv("CLIENT_ID"),
            "client_secret": os.getenv("CLIENT_SECRET"),
        }

        try:
            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(
                    url=TOKEN_URL, headers=headers, data=payload
                ) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        logger.info("Successfully retrieved new token")
                        return token_data
                    else:
                        error_msg = (
                            f"Failed to get new token. Status: {response.status}"
                        )
                        logger.error(error_msg)
                        raise Exception(error_msg)
        except Exception as e:
            logger.error(f"Error in get_new_token: {str(e)}")
            raise

    @circuit_breaker("token_service")
    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def get_new_token(self) -> Dict[str, Any]:
        """
        Get a new authentication token.

        Returns:
            Dict[str, Any]: Token data containing access_token and id_token

        Raises:
            Exception: If token retrieval fails
        """
        TOKEN_URL = os.getenv("TOKEN_URL")
        if not TOKEN_URL:
            raise ValueError("TOKEN_URL environment variable is not set")
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {TOKEN_AUTHORIZATION}",
        }
        payload = json.dumps(
            {
                "scope": "Public NonPII PII PHI openid",
                "assertion": ASSERTION,
                "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            }
        )

        try:
            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(
                    url=TOKEN_URL, headers=headers, data=payload
                ) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        logger.info("Successfully retrieved new token")
                        return token_data
                    else:
                        error_msg = (
                            f"Failed to get new token. Status: {response.status}"
                        )
                        logger.error(error_msg)
                        raise Exception(error_msg)
        except Exception as e:
            logger.error(f"Error in get_new_token: {str(e)}")
            raise
