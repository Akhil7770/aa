import aiohttp
import json
import os
import ssl
import xmltodict
from typing import Dict, Any, Optional
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_not_exception_type,
)

from app.core.logger import logger
from app.core.session_manager import SessionManager
from app.core.circuitbreaker.circuit_breaker import circuit_breaker
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.services.accumulator_service import (
    AccumulatorServiceInterface,
    AccumulatorResponse,
)
from app.services.token_service import TokenService
from app.exception.exceptions import (
    AccumulatorNotFoundException,
    AccumulatorMemberNotFoundException,
)
from app.schemas.acumulator_request import AccumulatorRequestBuilder
from app.core import constants
from app.core.constants import ACCUMULATOR_URL


class AccumulatorServiceImpl(AccumulatorServiceInterface):
    """Service implementation for handling accumulator-related operations."""

    def __init__(self):
        # Create SSL context that doesn't verify certificates
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.token_service = TokenService()

    async def get_accumulator_xml(
        self, request: CostEstimatorRequest, headers: Optional[Dict[str, str]] = None
    ) -> AccumulatorResponse:
        """
        Get accumulator information for the given request.

        Args:
            request (CostEstimatorRequest): The accumulator request object

        Returns:
            AccumulatorResponse: The accumulator response data

        Raises:
            AccumulatorNotFoundException: If the accumulator request fails
        """
        try:
            accumulator_url = os.getenv("ACCUMULATOR_URL")
            if not accumulator_url:
                raise ValueError("ACCUMULATOR_URL environment variable is not set")

            token = SessionManager.get_token()
            if not token:
                logger.error(
                    "No token available in SessionManager. or token is expired"
                )
                raise ValueError("Authentication token not available")

            headers_data = {
                "Content-Type": "application/xml",
                "Authorization": f"Bearer {token}",
                "app_name": constants.APP_NAME,
            }
            request_builder = AccumulatorRequestBuilder()
            xml_request = request_builder.build_xml_request(request, headers)
            logger.info(f"Accumulator Request: {xml_request}")

            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                # First attempt
                async with session.post(
                    url=f"{accumulator_url}",
                    headers=headers_data,
                    data=xml_request,
                ) as response:
                    response_text = await response.text()
                    if (
                        response_text != ""
                        and response_text is not None
                        and "accumulatorsResponse" in response_text
                    ):
                        response_dict = xmltodict.parse(response_text)
                        response_dict = request_builder.remove_namespaces(response_dict)
                    else:
                        logger.error(f"Response text: {response_text}")
                        raise ValueError("Invalid response from accumulator service")
                    if (
                        type(response_dict) is dict
                        and "readAccumulatorsResponse"
                        not in response_dict["accumulatorsResponse"]
                    ):
                        if (
                            "MBR NOT FOUND"
                            in response_dict["accumulatorsResponse"]["status"][
                                "additionalStatus"
                            ]["detail"]
                        ):
                            raise AccumulatorMemberNotFoundException(
                                message=f"Status {response.status}: {response_dict['accumulatorsResponse']['status']['additionalStatus']['detail'].split(';')[0]}",
                            )
                        logger.error(f"Response text: {response_text}")
                        raise ValueError("Invalid response from accumulator service")

                    response_data = {"readAccumulatorsResponse": response_dict["accumulatorsResponse"]["readAccumulatorsResponse"]}  # type: ignore
                    if response.status == 401:  # Token expired
                        SessionManager.clear_token()
                        return await self.get_accumulator(request)

                    if response.status == 400:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator request failed with status 400: "
                                f"{response_json.get('httpMessage', 'Bad Request')} - "
                                f"{response_json.get('moreInformation', 'Invalid request data')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator request failed with status 400: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )

                    if response.status == 500:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator service error with status 500: "
                                f"{response_json.get('httpMessage', 'Internal Server Error')} - "
                                f"{response_json.get('moreInformation', 'Service temporarily unavailable')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator service error with status 500: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )

                    if response.status != 200:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator request failed with status {response.status}: "
                                f"{response_json.get('httpMessage', 'Request failed')} - "
                                f"{response_json.get('moreInformation', 'Unknown error')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator request failed with status {response.status}: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )
                    # Success
                    accumulator_response = AccumulatorResponse(**response_data)
                    logger.info(f"Accumulator Service Response: {accumulator_response}")
                    return accumulator_response

        except AccumulatorNotFoundException:
            raise
        except AccumulatorMemberNotFoundException:
            raise
        except Exception as e:
            logger.error(f"Unexpected error in get_accumulator: {str(e)}")
            raise e

    @circuit_breaker("accumulator_service")
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_not_exception_type(AccumulatorNotFoundException),
    )
    async def get_accumulator(
        self, request: CostEstimatorRequest, headers: Optional[Dict[str, str]] = None
    ) -> AccumulatorResponse:
        """
        Get accumulator information for the given request.

        Args:
            request (CostEstimatorRequest): The accumulator request object

        Returns:
            AccumulatorResponse: The accumulator response data

        Raises:
            AccumulatorNotFoundException: If the accumulator request fails
        """
        try:
            ACCUMULATOR_URL = os.getenv("ACCUMULATOR_URL")
            if not ACCUMULATOR_URL:
                raise ValueError("ACCUMULATOR_URL environment variable is not set")

            token = SessionManager.get_token()
            if not token:
                # Get new token and store it
                token = await self.token_service.get_new_token()
                # TODO: Fix this, since token is a dict here, not a string
                SessionManager.set_token(token)

            if isinstance(token, dict):
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token['access_token']}",
                    "id_token": f"{token['id_token']}",
                }

            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(
                    url=f"{ACCUMULATOR_URL}/{request.membershipId}/accumulators?benefitProductType=Medical",
                    headers=headers,
                ) as response:
                    response_text = await response.text()

                    if response.status == 401:  # Token expired
                        SessionManager.clear_token()
                        return await self.get_accumulator(request)

                    if response.status == 400:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator request failed with status 400: "
                                f"{response_json.get('httpMessage', 'Bad Request')} - "
                                f"{response_json.get('moreInformation', 'Invalid request data')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator request failed with status 400: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )

                    if response.status == 500:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator service error with status 500: "
                                f"{response_json.get('httpMessage', 'Internal Server Error')} - "
                                f"{response_json.get('moreInformation', 'Service temporarily unavailable')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator service error with status 500: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )

                    if response.status != 200:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator request failed with status {response.status}: "
                                f"{response_json.get('httpMessage', 'Request failed')} - "
                                f"{response_json.get('moreInformation', 'Unknown error')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator request failed with status {response.status}: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )
                    # Success
                    response_data = await response.json()
                    accumulator_response = AccumulatorResponse(**response_data)
                    return accumulator_response

        except AccumulatorNotFoundException:
            raise
        except Exception as e:
            logger.error(f"Error in get_accumulator: {str(e)}")
            raise AccumulatorNotFoundException(
                message=str(e),
                accumulator_request=request.model_dump(),
            )
